document.addEventListener("DOMContentLoaded", function () {
    hideAllSections();
    document.getElementById("userSelection").style.display = "block";
});

function hideAllSections() {
    document.getElementById("userSelection").style.display = "none";
    document.getElementById("studentLogin").style.display = "none";
    document.getElementById("adminLogin").style.display = "none";
    document.getElementById("studentDashboard").style.display = "none";
    document.getElementById("adminDashboard").style.display = "none";
}

function showLogin(type) {
    hideAllSections();
    if (type === "student") {
        document.getElementById("studentLogin").style.display = "block";
    } else {
        document.getElementById("adminLogin").style.display = "block";
    }
}

function goBack() {
    hideAllSections();
    document.getElementById("userSelection").style.display = "block";
}

async function studentLogin() {
    const studentId = document.getElementById("rollNumber").value;
    const response = await fetch("http://localhost:5000/api/students/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ studentId }),
    });

    const data = await response.json();
    if (response.ok) {
        localStorage.setItem("userType", "student");
        localStorage.setItem("studentId", studentId);
        showStudentDashboard();
    } else {
        alert("Login failed: " + data.message);
    }
}

async function adminLogin() {
    const username = document.getElementById("adminUsername").value;
    const password = document.getElementById("adminPassword").value;

    const response = await fetch("http://localhost:5000/api/admins/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
    });

    const data = await response.json();
    console.log("Admin login response:", data);
    if (response.ok) {
        localStorage.setItem("userType", "admin");
        showAdminDashboard();
    } else {
        alert("Login failed: " + data.message);
    }
}

function showStudentDashboard() {
    hideAllSections();
    document.getElementById("studentDashboard").style.display = "block";
    loadCourses();
    loadSchedule();
}

function showAdminDashboard() {
    hideAllSections();
    document.getElementById("adminDashboard").style.display = "block";
    loadAvailableCourses();
}

function logout() {
    localStorage.removeItem("userType");
    localStorage.removeItem("studentId");
    hideAllSections();
    document.getElementById("userSelection").style.display = "block";
}

async function loadCourses() {
    const response = await fetch("http://localhost:5000/api/students/courses");
    const courses = await response.json();
    const coursesContainer = document.getElementById("courses");
    coursesContainer.innerHTML = '';

    courses.forEach(course => {
        const courseDiv = document.createElement("div");
        courseDiv.style.display = "flex";
        courseDiv.style.justifyContent = "space-between";
        courseDiv.style.alignItems = "center";
        courseDiv.style.marginBottom = "10px";

        const courseInfo = document.createElement("span");
        courseInfo.textContent = `${course.courseName} - Seats: ${course.availableSeats}`;

        const buttonsDiv = document.createElement("div");
        buttonsDiv.style.display = "flex";
        buttonsDiv.style.gap = "10px";

        const registerButton = document.createElement("button");
        registerButton.textContent = "Register";
        registerButton.onclick = () => registerCourse(course.courseName);

        const subscribeButton = document.createElement("button");
        subscribeButton.textContent = "Subscribe";
        subscribeButton.onclick = () => subscribeToCourse(course.courseName);

        buttonsDiv.appendChild(registerButton);
        buttonsDiv.appendChild(subscribeButton);

        courseDiv.appendChild(courseInfo);
        courseDiv.appendChild(buttonsDiv);

        coursesContainer.appendChild(courseDiv);
    });
}

async function fetchCourseDetails(courseName) {
    const response = await fetch(`http://localhost:5000/api/students/course/${encodeURIComponent(courseName)}`);
    const course = await response.json();

    if (response.ok) {
        let prerequisitesList = "<h3>Prerequisites</h3>";
        if (course.prerequisites && course.prerequisites.length > 0) {
            prerequisitesList += "<ul>";
            course.prerequisites.forEach(prerequisite => {
                prerequisitesList += `<li>${prerequisite.courseName}</li>`;
            });
            prerequisitesList += "</ul>";
        } else {
            prerequisitesList += "<p>No prerequisites for this course.</p>";
        }
        document.getElementById("prerequisites").innerHTML = prerequisitesList;
    } else {
        alert("Error: " + course.message);
    }
}

async function registerCourse(courseName) {
    const studentId = localStorage.getItem("studentId");
    const response = await fetch("http://localhost:5000/api/students/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rollNumber: studentId, courseName }),
    });

    const data = await response.json();
    alert(data.message);
    loadCourses();
}

async function subscribeToCourse(courseName) {
    const studentId = localStorage.getItem("studentId");
    const response = await fetch("http://localhost:5000/api/students/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ studentId, courseName }),
    });

    const data = await response.json();
    alert(data.message);
}

async function addCourse() {
    const courseData = {
        courseName: document.getElementById("courseName").value,
        department: document.getElementById("departmentName").value,
        schedule: { day: document.getElementById("day").value },
    };

    const response = await fetch("http://localhost:5000/api/admins/course", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(courseData),
    });

    alert("Course added successfully!");
}

async function updateCourse() {
    const courseName = document.getElementById("updateCourseName").value;
    const courseData = {
        department: document.getElementById("updateDepartment").value,
        schedule: { day: document.getElementById("updateDay").value },
    };

    const response = await fetch(`http://localhost:5000/api/admins/course/update/${courseName}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(courseData),
    });

    const data = await response.json();
    alert(data.message);
}

async function deleteCourse() {
    const courseName = document.getElementById("deleteCourseName").value;

    const response = await fetch(`http://localhost:5000/api/admins/course/delete/${courseName}`, {
        method: "DELETE",
    });

    const data = await response.json();
    alert(data.message);
}

async function loadSchedule() {
    const studentId = localStorage.getItem("studentId");
    if (!studentId) return;

    const response = await fetch(`http://localhost:5000/api/students/schedule/${studentId}`);
    const schedule = await response.json();

    const scheduleTable = document.getElementById("scheduleTable");
    scheduleTable.innerHTML = "<tr><th>Day</th><th>Time</th><th>Course</th></tr>";

    schedule.forEach(course => {
        scheduleTable.innerHTML += `<tr>
            <td>${course.schedule.day}</td>
            <td>${course.schedule.startTime} - ${course.schedule.endTime}</td>
            <td>${course.courseName}</td>
        </tr>`;
    });
}

async function filterCourses() {
    const department = document.getElementById("department").value;
    const day = document.getElementById("day").value;

    const response = await fetch(`http://localhost:5000/api/students/courses/filter?department=${department}&day=${day}`);
    const courses = await response.json();

    let courseList = "<h3>Filtered Courses</h3><ul>";
    courses.forEach(course => {
        courseList += `<li>${course.courseName} - ${course.department}</li>`;
    });
    courseList += "</ul>";
    document.getElementById("filteredCourses").innerHTML = courseList;
}

async function loadAvailableCourses() {
    const response = await fetch("http://localhost:5000/api/admins/courses/available");
    const courses = await response.json();
    document.getElementById("availableCourses").innerHTML = courses.map(course => 
        `<div>${course.courseName} - Seats: ${course.availableSeats}</div>`).join('');
}

async function overrideRegistration() {
    const studentRoll = document.getElementById("studentRoll").value;
    const courseName = document.getElementById("overrideCourseName").value;

    const response = await fetch("http://localhost:5000/api/admins/override", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rollNumber: studentRoll, courseName }),
    });

    const data = await response.json();
    alert(data.message);
}

async function adjustSeats() {
    const courseName = document.getElementById("adjustSeatsCourseName").value;
    const availableSeats = document.getElementById("adjustSeats").value;

    const response = await fetch(`http://localhost:5000/api/admins/course/seats/${courseName}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ availableSeats }),
    });

    const data = await response.json();
    alert(data.message);
}

async function loadIncompletePrerequisites() {
    const courseName = document.getElementById("incompletePrerequisiteCourseName").value;
    if (!courseName) {
        alert("Please enter a course name.");
        return;
    }

    const response = await fetch(`http://localhost:5000/api/admins/students/incomplete-prerequisites/${courseName}`);
    const students = await response.json();

    if (response.ok) {
        let studentList = "<h3>Students with Incomplete Prerequisites</h3><ul>";
        students.forEach(student => {
            studentList += `<li>${student.rollNumber}</li>`;
        });
        studentList += "</ul>";
        document.getElementById("incompletePrerequisites").innerHTML = studentList;
    } else {
        alert("Error: " + students.message);
    }
}

async function generateReport(reportType) {
    const courseName = document.getElementById("reportCourseName").value;
    let endpoint = "";

    switch (reportType) {
        case "students-registered":
            if (!courseName) {
                alert("Please enter a course name.");
                return;
            }
            endpoint = `/api/admins/report/students-registered/${courseName}`;
            break;
        case "courses-available":
            endpoint = "/api/admins/report/courses-available";
            break;
        case "students-incomplete-prerequisites":
            if (!courseName) {
                alert("Please enter a course name.");
                return;
            }
            endpoint = `/api/admins/report/students-incomplete-prerequisites/${courseName}`;
            break;
        default:
            alert("Invalid report type.");
            return;
    }

    const response = await fetch(`http://localhost:5000${endpoint}`);
    const data = await response.json();

    if (response.ok) {
        let reportResults = "<h3>Report Results</h3><ul>";
        if (Array.isArray(data)) {
            data.forEach(item => {
                if (item.rollNumber) {
                    reportResults += `<li>Student Roll Number: ${item.rollNumber}</li>`;
                } else if (item.courseName) {
                    reportResults += `<li>Course: ${item.courseName} - Seats: ${item.availableSeats}</li>`;
                }
            });
        } else {
            reportResults += `<li>${JSON.stringify(data)}</li>`;
        }
        reportResults += "</ul>";
        document.getElementById("reportResults").innerHTML = reportResults;
    } else {
        alert("Error: " + data.message);
    }
}