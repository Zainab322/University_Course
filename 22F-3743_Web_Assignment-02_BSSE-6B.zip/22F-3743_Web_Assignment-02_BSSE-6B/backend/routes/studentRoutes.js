const express = require("express");
const Student = require("../models/Student");
const Course = require("../models/Course");

const router = express.Router();

router.post("/login", async (req, res) => {
  try {
    console.log("Incoming Request Body:", req.body);

    const { studentId } = req.body;
    if (!studentId) {
      return res.status(400).json({ message: "Missing studentId in request" });
    }

    const queryId = studentId.toString().trim();

    console.log("Searching for rollNumber:", queryId);

    const student = await Student.findOne({ rollNumber: { $regex: `^${queryId}$`, $options: "i" } });

    console.log("MongoDB Query Result:", student);

    if (!student) {
      return res.status(404).json({ message: "Student not found" });
    }

    res.json(student);
  } catch (error) {
    console.error("Login Error:", error);
    res.status(500).json({ message: "Server error", error });
  }
});

router.get("/courses", async (req, res) => {
  try {
    const courses = await Course.find();
    res.json(courses);
  } catch (error) {
    console.error("Error fetching courses:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.get("/courses/:name", async (req, res) => {
    try {
        const courseName = req.params.name;
        
        console.log(`Fetching course: ${courseName}`);

        const course = await Course.findOne({ courseName })
            .populate("prerequisites", "courseName"); 

        console.log("Fetched Course:", course);

        if (!course) {
            return res.status(404).json({ message: "Course not found" });
        }

        res.json(course);
    } catch (error) {
        console.error("Error fetching course:", error);
        res.status(500).json({ message: "Server error" });
    }
});


module.exports = router;
