const express = require('express');
const Admin = require('../models/Admin');
const Course = require('../models/Course');
const Student = require('../models/Student');

const router = express.Router();

router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const admin = await Admin.findOne({ username, password });
    if (!admin) return res.status(404).json({ message: "Admin not found" });
    res.json(admin);
});

router.post('/course', async (req, res) => {
    const newCourse = new Course(req.body);
    await newCourse.save();
    res.json(newCourse);
});

router.put('/course/:id', async (req, res) => {
    const updatedCourse = await Course.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedCourse);
});

router.delete('/course/:id', async (req, res) => {
    await Course.findByIdAndDelete(req.params.id);
    res.json({ message: "Course deleted successfully" });
});

router.put('/course/prerequisites/:id', async (req, res) => {
    const { prerequisites } = req.body;
    const updatedCourse = await Course.findByIdAndUpdate(req.params.id, { prerequisites }, { new: true });
    res.json({ message: "Prerequisites updated successfully", course: updatedCourse });
});

router.get('/course/students/:courseId', async (req, res) => {
    const students = await Student.find({ registeredCourses: req.params.courseId });
    res.json(students);
});

router.post('/override', async (req, res) => {
    const { rollNumber, courseId } = req.body;

    const student = await Student.findOne({ rollNumber });
    if (!student) return res.status(404).json({ message: "Student not found" });

    const course = await Course.findById(courseId);
    if (!course) return res.status(404).json({ message: "Course not found" });

    student.registeredCourses.push(course._id);
    await student.save();

    res.json({ message: "Registration overridden successfully!" });
});

router.put('/course/seats/:id', async (req, res) => {
    const { availableSeats } = req.body;
    const updatedCourse = await Course.findByIdAndUpdate(req.params.id, { availableSeats }, { new: true });
    res.json({ message: "Seats updated successfully", course: updatedCourse });
});

router.get('/courses/available', async (req, res) => {
    const courses = await Course.find({ availableSeats: { $gt: 0 } });
    res.json(courses);
});

router.get('/students/incomplete-prerequisites/:courseId', async (req, res) => {
    const course = await Course.findById(req.params.courseId).populate('prerequisites');
    if (!course) return res.status(404).json({ message: "Course not found" });

    const students = await Student.find({ registeredCourses: { $in: course.prerequisites } });
    res.json(students);
});

module.exports = router;