const CourseSchema = new mongoose.Schema({
    courseName: String,
    department: String,
    schedule: { day: String, time: String }, 
    prerequisites: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Course' }],
    availableSeats: Number
});

const Course = mongoose.model('Course', CourseSchema);
