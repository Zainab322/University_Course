const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(express.json());
app.use(cors());
app.use(express.static('public'));

mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log("MongoDB Connected"))
    .catch(err => console.log("MongoDB Connection Error:", err));

const Student = mongoose.model('Student', new mongoose.Schema({
    rollNumber: { type: String, required: true, unique: true },
    registeredCourses: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Course' }]
}));

const Admin = mongoose.model('Admin', new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true }
}));

const Course = mongoose.model('Course', new mongoose.Schema({
    courseName: { type: String, required: true, unique: true },
    department: String,
    schedule: { day: String, startTime: String, endTime: String },
    prerequisites: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Course' }],
    availableSeats: Number
}));

const Subscription = mongoose.model('Subscription', new mongoose.Schema({
    studentId: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    courseId: { type: mongoose.Schema.Types.ObjectId, ref: 'Course', required: true }
}));

// ------------------- STUDENT FUNCTIONALITIES ------------------- //

app.post('/api/students/login', async (req, res) => {
    try {
        const { studentId } = req.body;
        if (!studentId) return res.status(400).json({ message: "Missing studentId" });

        const queryId = studentId.toString().trim();
        const student = await Student.findOne({ rollNumber: { $regex: `^${queryId}$`, $options: 'i' } });

        if (!student) return res.status(404).json({ message: "Student not found" });

        res.json(student);
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

app.get('/api/students/courses', async (req, res) => {
    try {
        const courses = await Course.find();
        res.json(courses);
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

app.get('/api/students/courses/seats', async (req, res) => {
    try {
        const courses = await Course.find({}, 'courseName availableSeats');
        res.json(courses);
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

app.get('/api/students/schedule/:rollNumber', async (req, res) => {
    try {
        const student = await Student.findOne({ rollNumber: req.params.rollNumber }).populate('registeredCourses');
        res.json(student ? student.registeredCourses : []);
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

app.post('/api/students/register', async (req, res) => {
    try {
        const { rollNumber, courseName } = req.body;

        const student = await Student.findOne({ rollNumber });
        if (!student) return res.status(404).json({ message: "Student not found" });

        const course = await Course.findOne({ courseName });
        if (!course) return res.status(404).json({ message: "Course not found" });

        if (course.availableSeats <= 0) return res.status(400).json({ message: "No seats available" });

        student.registeredCourses.push(course._id);
        course.availableSeats -= 1;
        
        await student.save();
        await course.save();

        res.json({ message: "Course registered successfully!" });
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

app.get('/api/students/courses/filter', async (req, res) => {
    try {
        const { department, day } = req.query;
        let filter = {};
        if (department) filter.department = department;
        if (day) filter['schedule.day'] = day;

        const courses = await Course.find(filter);
        res.json(courses);
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

app.get('/api/students/course/:courseName', async (req, res) => {
    try {
        const course = await Course.findOne({ courseName: req.params.courseName }).populate('prerequisites');
        if (!course) return res.status(404).json({ message: "Course not found" });
        res.json(course);
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

app.post('/api/students/subscribe', async (req, res) => {
    try {
        const { studentId, courseName } = req.body;

        const student = await Student.findOne({ rollNumber: studentId });
        if (!student) return res.status(404).json({ message: "Student not found" });

        const course = await Course.findOne({ courseName });
        if (!course) return res.status(404).json({ message: "Course not found" });

        const existingSubscription = await Subscription.findOne({ studentId: student._id, courseId: course._id });
        if (existingSubscription) return res.status(400).json({ message: "Already subscribed" });

        const subscription = new Subscription({ studentId: student._id, courseId: course._id });
        await subscription.save();

        res.json({ message: "Subscribed successfully!" });
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

app.post('/api/students/notify', async (req, res) => {
    try {
        const { courseName } = req.body;

        const course = await Course.findOne({ courseName });
        if (!course) return res.status(404).json({ message: "Course not found" });

        const subscriptions = await Subscription.find({ courseId: course._id }).populate('studentId');
        const students = subscriptions.map(sub => sub.studentId);

        students.forEach(student => {
            console.log(`Notifying student ${student.rollNumber} about available seats in ${course.courseName}`);
        });

        res.json({ message: "Notifications sent successfully!" });
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

// ------------------- ADMIN FUNCTIONALITIES ------------------- //

app.post('/api/admins/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        console.log("Admin login attempt:", username);
        const admin = await Admin.findOne({ username, password });
        if (!admin) {
            console.log("Admin not found or invalid credentials");
            return res.status(404).json({ message: "Invalid credentials" });
        }
        console.log("Admin login successful:", admin);
        res.json({ message: "Login successful", admin });
    } catch (error) {
        console.error("Admin login error:", error);
        res.status(500).json({ message: "Server error", error });
    }
});

app.post('/api/admins/course', async (req, res) => {
    try {
        const newCourse = new Course(req.body);
        await newCourse.save();
        res.json({ message: "Course added successfully", course: newCourse });
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

app.put('/api/admins/course/update/:courseName', async (req, res) => {
    try {
        const { courseName } = req.params;
        const updatedCourse = await Course.findOneAndUpdate({ courseName }, req.body, { new: true });
        if (!updatedCourse) return res.status(404).json({ message: "Course not found" });
        res.json({ message: "Course updated successfully", course: updatedCourse });
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

app.delete('/api/admins/course/delete/:courseName', async (req, res) => {
    try {
        const { courseName } = req.params;
        const deletedCourse = await Course.findOneAndDelete({ courseName });
        if (!deletedCourse) return res.status(404).json({ message: "Course not found" });
        res.json({ message: "Course deleted successfully" });
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

app.get('/api/admins/course/students/:courseName', async (req, res) => {
    try {
        const { courseName } = req.params;
        const course = await Course.findOne({ courseName });
        if (!course) return res.status(404).json({ message: "Course not found" });

        const students = await Student.find({ registeredCourses: course._id });
        res.json(students);
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

app.post('/api/admins/override', async (req, res) => {
    try {
        const { rollNumber, courseName } = req.body;

        const student = await Student.findOne({ rollNumber });
        if (!student) return res.status(404).json({ message: "Student not found" });

        const course = await Course.findOne({ courseName });
        if (!course) return res.status(404).json({ message: "Course not found" });

        student.registeredCourses.push(course._id);
        await student.save();

        res.json({ message: "Registration overridden successfully!" });
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

app.put('/api/admins/course/seats/:courseName', async (req, res) => {
    try {
        const { courseName } = req.params;
        const { availableSeats } = req.body;

        const updatedCourse = await Course.findOneAndUpdate({ courseName }, { availableSeats }, { new: true });
        if (!updatedCourse) return res.status(404).json({ message: "Course not found" });

        await fetch("http://localhost:5000/api/students/notify", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ courseName }),
        });

        res.json({ message: "Seats updated successfully", course: updatedCourse });
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

app.get('/api/admins/courses/available', async (req, res) => {
    try {
        const courses = await Course.find({ availableSeats: { $gt: 0 } });
        res.json(courses);
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

app.get('/api/admins/students/incomplete-prerequisites/:courseName', async (req, res) => {
    try {
        const { courseName } = req.params;
        const course = await Course.findOne({ courseName }).populate('prerequisites');
        if (!course) return res.status(404).json({ message: "Course not found" });

        const students = await Student.find({ registeredCourses: { $nin: course.prerequisites } });
        res.json(students);
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

app.get('/api/admins/report/students-registered/:courseName', async (req, res) => {
    try {
        const { courseName } = req.params;
        const course = await Course.findOne({ courseName });
        if (!course) return res.status(404).json({ message: "Course not found" });

        const students = await Student.find({ registeredCourses: course._id });
        res.json(students);
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

app.get('/api/admins/report/courses-available', async (req, res) => {
    try {
        const courses = await Course.find({ availableSeats: { $gt: 0 } });
        res.json(courses);
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

app.get('/api/admins/report/students-incomplete-prerequisites/:courseName', async (req, res) => {
    try {
        const { courseName } = req.params;
        const course = await Course.findOne({ courseName }).populate('prerequisites');
        if (!course) return res.status(404).json({ message: "Course not found" });

        const students = await Student.find({ registeredCourses: { $nin: course.prerequisites } });
        res.json(students);
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
});

app.listen(5000, () => console.log("Server running on port 5000"));